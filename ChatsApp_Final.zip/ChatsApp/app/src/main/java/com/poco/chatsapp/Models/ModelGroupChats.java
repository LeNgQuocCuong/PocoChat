package com.poco.chatsapp.Models;

public class ModelGroupChats {
    String groupId,groupTitle,groupDescription,groupIcon,timestamp,createdBy;

    public ModelGroupChats() {
    }
}
