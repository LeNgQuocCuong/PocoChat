package com.poco.chatsapp.Activities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

import com.poco.chatsapp.R;

public class WelcomeAcivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_acivity);
        new Handler().postDelayed(
                new Runnable() {
                    @Override
                    public void run() {
                        Intent intent= new Intent(WelcomeAcivity.this,StartActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }, 2000
        );
    }
}